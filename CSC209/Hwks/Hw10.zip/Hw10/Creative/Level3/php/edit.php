<?php
// Get the JSON data sent from JavaScript
$jsonData = file_get_contents('php://input');
$changes = json_decode($jsonData, true);

// Extract data from the array
// changes[0] = oldUsername
// changes[1] = newUsername (optional)
// changes[2] = newPassword (optional)

$oldUsername = $changes[0] ?? '';
$newUsername = $changes[1] ?? '';
$newPassword = $changes[2] ?? '';

if (empty($oldUsername)) {
    echo json_encode(["error" => "No username provided"]);
    exit;
}

$usersFile = '../users.json';

// Read users.json
if (!file_exists($usersFile)) {
    echo json_encode(["error" => "Users file not found"]);
    exit;
}

$jsonContent = file_get_contents($usersFile);
$users = json_decode($jsonContent, true);

// Find the user
$userIndex = -1;
for ($i = 0; $i < count($users); $i++) {
    if ($users[$i]['username'] === $oldUsername) {
        $userIndex = $i;
        break;
    }
}

if ($userIndex === -1) {
    echo "user not found";
    exit;
}

// Update username if provided and different
if (!empty($newUsername) && $newUsername !== $oldUsername) {
    // Check if new username already exists
    foreach ($users as $user) {
        if ($user['username'] === $newUsername) {
            echo json_encode(["error" => "Username already exists"]);
            exit;
        }
    }
    
    // Update username
    $users[$userIndex]['username'] = $newUsername;
    
    // Rename the user's folder
    $oldFolder = "../Users/" . $oldUsername;
    $newFolder = "../Users/" . $newUsername;
    
    if (file_exists($oldFolder)) {
        rename($oldFolder, $newFolder);
    }
    
    // Also check for User# folder and rename if exists
    $userNumber = $userIndex + 1;
    $oldNumberFolder = "../Users/User" . $userNumber;
    if (file_exists($oldNumberFolder) && !file_exists($newFolder)) {
        rename($oldNumberFolder, $newFolder);
    }
}

// Update password if provided
if (!empty($newPassword)) {
    $users[$userIndex]['password'] = $newPassword;
}

// Save the updated JSON
file_put_contents($usersFile, json_encode($users, JSON_PRETTY_PRINT));

// Return the updated user list
echo json_encode($users);
?>