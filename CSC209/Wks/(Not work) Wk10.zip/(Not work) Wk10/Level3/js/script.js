function makeTable() {
    var body = document.getElementsByTagName("body")[0]; 

    var table = document.createElement("table"); 
    body.appendChild(table); 
    var headerrow = document.createElement("tr"); 

    table.appendChild(headerrow); 
    // username
    var userheader = document.createElement("th"); 
    userheader.textContent = "User"; 
    headerrow.appendChild(userheader); 

    //password
    var pwheader = document.createElement("th"); 
    pwheader.textContent = "Password"; 
    headerrow.appendChild(pwheader); 

    // loggedtimes 
    var loggedTimesHeader = document.createElement("th"); 
    loggedTimesHeader.textContent = "Logged times"; 
    headerrow.appendChild(loggedTimesHeader);   
    
    for (let i = 0; i < list.length; i++) {
        var tab_row = document.createElement("tr"); 
        table.appendChild(tab_row); 

        var userdata = document.createElement("td"); 
        userdata.textContent = list[i].username;
        tab_row.appendChild(userdata); 

        var pwdata = document.createElement("td"); 
        pwdata.textContent = list[i].password; 
        tab_row.appendChild(pwdata); 

        var ltdata = document.createElement("td"); 
        ltdata.textContent = list[i].loggedtimes; 
        tab_row.appendChild(ltdata); 
    }
}

function sortedTable(sortBy) {
    var table = document.getElementsByTagName("table")[0]; 
    if (table != null) {
        table.remove(); 
    }
    if (sortBy == "user") {
        list.sort(function(a, b) {return a.username.localeCompare(b.username)}); 
    }
    else if (sortBy == "password") {
        list.sort(function(a, b) {return  a.password.localeCompare(b.password)}); 
    }
    else if (sortBy == "loggedtimes") {
        list.sort(function(a, b) {return a.loggedtimes - b.loggedtimes}); 
    }

    makeTable(list); 
}

function timeLoggedIn(timeStart) {
    var timeStop = Date.now(); 
    var millisecondsPassed = timeStop - timeStart; 
    var minutesPassed = Math.floor(millisecondsPassed / 60000);
    return minutesPassed; 
}

